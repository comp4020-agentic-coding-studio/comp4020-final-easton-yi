from pathlib import Path
import json,math,numpy as np,moderngl,trimesh
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).parent;OUT=ROOT/'output'
ctx=moderngl.create_standalone_context(backend='egl')
print('Renderer:',ctx.info['GL_RENDERER'],flush=True)
VS='''#version 330
in vec3 pos;in vec3 norm;in vec3 localp;in vec3 localn;in float seed;in float tag;
uniform mat4 VP;uniform mat4 lightVP;
out vec3 N;out vec3 P;out vec3 L;out vec3 LN;out vec4 shadowPos;out float S;out float T;
void main(){P=pos;N=norm;L=localp;LN=localn;S=seed;T=tag;shadowPos=lightVP*vec4(pos,1);gl_Position=VP*vec4(pos,1);}
'''
FS='''#version 330
in vec3 N;in vec3 P;in vec3 L;in vec3 LN;in vec4 shadowPos;in float S;in float T;
uniform sampler2D shadowMap;uniform vec3 eye;
out vec4 frag;
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p),u=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1,0)),u.x),mix(hash(i+vec2(0,1)),hash(i+vec2(1,1)),u.x),u.y);}
vec3 tone(vec3 x){return clamp((x*(2.51*x+.03))/(x*(2.43*x+.59)+.14),0.,1.);}
void main(){vec3 n=normalize(N);vec3 sun=normalize(vec3(22,46,16));float diff=max(dot(n,sun),0.);vec3 base;
if(T<.5){float across=abs(LN.y)>.6?L.z:L.y;float g=.5+.5*sin(across*24.+sin(L.x*.35+S*6.28)*1.8+noise(vec2(L.x*.6,across*2.+S*9.))*2.); if(abs(LN.x)>.6)g=.5+.5*sin(length(L.yz+vec2(.9,-.7))*44.);base=mix(vec3(.52,.31,.15),vec3(.72,.49,.28),.45+.35*g);base*=.94+.12*S;}
else if(T<1.5){base=vec3(.73,.68,.59)*( .98+.02*noise(P.xz*4.));}
else{base=vec3(.82,.82,.76);}
vec3 sh=shadowPos.xyz/shadowPos.w*.5+.5;float visible=1.;
if(sh.x>0.&&sh.x<1.&&sh.y>0.&&sh.y<1.&&sh.z<1.){visible=0.;float bias=max(.0012*(1.-diff),.0005);for(int i=-1;i<=1;i++)for(int j=-1;j<=1;j++){float d=texture(shadowMap,sh.xy+vec2(i,j)/2048.).r;visible+=sh.z-bias<=d?1.:.25;}visible/=9.;}
float hemi=.30+.12*n.y;vec3 c=base*(hemi+diff*visible*1.05);if(T<.5){float edge=1.-pow(max(dot(n,normalize(eye-P)),0.),.5);c+=edge*.025;}
c=tone(c*1.05);c=pow(c,vec3(1./2.2));frag=vec4(c,1.);}
'''
SHVS='''#version 330
in vec3 pos;uniform mat4 VP;void main(){gl_Position=VP*vec4(pos,1);}'''
SHFS='''#version 330
void main(){}'''
prog=ctx.program(vertex_shader=VS,fragment_shader=FS);sp=ctx.program(vertex_shader=SHVS,fragment_shader=SHFS)
box=trimesh.creation.box([1,1,1]);inds=box.faces.reshape(-1);bp=box.vertices[inds];bn=np.repeat(box.face_normals,3,axis=0)
def geometry(data,table=False):
 arrays=[]
 for i,p in enumerate(data['parts']):
  R=np.array(p['R']);local=bp*np.array(p['size']);world=local@R.T+p['p'];norm=bn@R.T;seed=np.full((len(bp),1),(i*137%997)/997);tag=np.zeros((len(bp),1));arrays.append(np.concatenate([world,norm,local,bn,seed,tag],axis=1))
 def addmesh(m,tag):
  ix=m.faces.reshape(-1);v=m.vertices[ix];n=np.repeat(m.face_normals,3,axis=0);arrays.append(np.concatenate([v,n,v,n,np.zeros((len(v),1)),np.full((len(v),1),tag)],axis=1))
 ground=trimesh.creation.box([500,.2,500]);ground.apply_translation([0,-2.2 if table else -.3,0]);addmesh(ground,2)
 if table:
  disk=trimesh.creation.cylinder(18,2,sections=128);T=trimesh.transformations.rotation_matrix(math.pi/2,[1,0,0]);disk.apply_transform(T);disk.apply_translation([0,-1,0]);addmesh(disk,1)
 return np.concatenate(arrays).astype('f4')
def look(eye,target):
 e=np.array(eye,float);t=np.array(target,float);f=t-e;f/=np.linalg.norm(f);s=np.cross(f,[0,1,0]);s/=np.linalg.norm(s);u=np.cross(s,f);m=np.eye(4);m[:3,:3]=[s,u,-f];m[:3,3]=-m[:3,:3]@e;return m

def persp(fov,aspect,near=.2,far=1000):
 f=1/math.tan(math.radians(fov)/2);m=np.zeros((4,4));m[0,0]=f/aspect;m[1,1]=f;m[2,2]=(far+near)/(near-far);m[2,3]=2*far*near/(near-far);m[3,2]=-1;return m

def ortho(r,near=.1,far=700):
 m=np.eye(4);m[0,0]=m[1,1]=1/r;m[2,2]=-2/(far-near);m[2,3]=-(far+near)/(far-near);return m

def mat(prog,k,m):prog[k].write(np.asarray(m,dtype='f4').T.tobytes())
def render(data,mode):
 name=data['name'];table=mode=='orbit' and name in ['doric','ionic','corinthian','stairs_132_current_sticks'];geo=geometry(data,table);vbo=ctx.buffer(geo.tobytes());vao=ctx.vertex_array(prog,[(vbo,'3f 3f 3f 3f 1f 1f','pos','norm','localp','localn','seed','tag')]);sv=ctx.vertex_array(sp,[(vbo,'3f 44x','pos')])
 lo,hi=map(np.array,data['bounds']);center=(lo+hi)/2;extent=hi-lo
 lcenter=center.copy();radius=max(extent)*.9+16;sun=np.array([22,46,16],float);sun/=np.linalg.norm(sun);le=lcenter+sun*300;lvp=ortho(radius)@look(le,lcenter)
 tex=ctx.depth_texture((2048,2048));tex.compare_func='';tex.filter=(moderngl.NEAREST,moderngl.NEAREST);tex.repeat_x=tex.repeat_y=False;sf=ctx.framebuffer(depth_attachment=tex);sf.use();sf.clear(depth=1);ctx.enable(moderngl.DEPTH_TEST);ctx.disable(moderngl.CULL_FACE);mat(sp,'VP',lvp);sv.render()
 W,H=1440,1080;fb=ctx.simple_framebuffer((W,H),components=4,samples=4);fb.use();fb.clear(.94,.935,.90,1,depth=1)
 if mode=='orbit':
  blo=np.minimum(lo,[-18,-1,-18]);bhi=np.maximum(hi,[18,2,18]);target=(blo+bhi)/2;target[1]=max(0,target[1]*.8);sr=np.linalg.norm(bhi-blo)/2;distance=sr/math.sin(math.radians(35)/2)*.95;phi=.95;theta=math.pi/4;eye=target+distance*np.array([math.sin(phi)*math.sin(theta),math.cos(phi),math.sin(phi)*math.cos(theta)]);fov=35
 elif mode=='eye':
  if name in ['doric','ionic','corinthian']:eye=np.array([8,1.65,30]);target=np.array([0,14,0]);fov=55
  elif name=='entrance_composition':eye=np.array([20,1.65,74]);target=np.array([0,19,0]);fov=55
  elif name=='broad_shallow_stairs':eye=np.array([18,1.65,60]);target=np.array([0,5,0]);fov=65
  elif name=='stairs_132_current_sticks':eye=np.array([12,1.65,29]);target=np.array([0,2,0]);fov=55
  else:eye=np.array([45,1.65,92]);target=np.array([0,29,5]);fov=55
 else:
  eye=np.array([110,32,12]);target=np.array([0,30,8]);fov=42
 mat(prog,'VP',persp(fov,W/H)@look(eye,target));mat(prog,'lightVP',lvp);prog['eye'].value=tuple(eye);tex.use(0);prog['shadowMap'].value=0;vao.render()
 out=ctx.simple_framebuffer((W,H),components=4);ctx.copy_framebuffer(out,fb);im=Image.frombytes('RGBA',(W,H),out.read(components=4)).transpose(Image.Transpose.FLIP_TOP_BOTTOM).convert('RGB');im.save(OUT/f'{name}_{mode}.png')
 (OUT/f'{name}_{mode}_camera.json').write_text(json.dumps({'eye':eye.tolist(),'target':target.tolist(),'fov':fov,'viewport':[W,H],'camera_source':'viewport.ts fitAll/default angles' if mode=='orbit' else 'proposed human-eye view','not_live_site_screenshot':True},indent=2))
 for o in [vao,sv,vbo,tex,sf,fb,out]:o.release()
 print(name,mode,len(data['parts']),flush=True)
if __name__=='__main__':
 for e in json.loads((OUT/'manifest.json').read_text()):
  data=json.loads((OUT/(e['name']+'.json')).read_text())
  for mode in ['orbit','eye']:render(data,mode)
  if e['name']=='spillway_fins':render(data,'side')
