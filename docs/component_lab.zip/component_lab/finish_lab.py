from pathlib import Path
import json, copy, numpy as np, trimesh
from PIL import Image,ImageDraw,ImageFont
ROOT=Path(__file__).parent; OUT=ROOT/'output'
from render_lab import render
for n in ['stairs_132_current_sticks','broad_shallow_stairs','entrance_composition']:
 d=json.loads((OUT/(n+'.json')).read_text())
 for mode in ['orbit','eye']:render(d,mode)
result=json.loads((OUT/'stairs_physics_result.json').read_text())
d=copy.deepcopy(json.loads((OUT/'stairs_132_current_sticks.json').read_text()))
for body in result['finalBodies']:
 p=d['parts'][int(body['id'].split('-')[1])];p['p']=body['p'];x,y,z,w=body['q'];p['R']=trimesh.transformations.quaternion_matrix([w,x,y,z])[:3,:3].tolist()
d['physical_status']='OFFLINE_PHYSICS_TESTED_SETTLED_POSES'
(OUT/'stairs_132_settled.json').write_text(json.dumps(d,separators=(',',':')))
render(d,'orbit');(OUT/'stairs_132_current_sticks_orbit.png').rename(OUT/'stairs_132_settled_orbit.png');(OUT/'stairs_132_current_sticks_orbit_camera.json').rename(OUT/'stairs_132_settled_orbit_camera.json')
render(json.loads((OUT/'stairs_132_current_sticks.json').read_text()),'orbit')
F='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf';B='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
def font(n,b=False):return ImageFont.truetype(B if b else F,n)
def board(name,title,sub,items,cols):
 cw=720; ch=630;pad=28;top=150;rows=(len(items)+cols-1)//cols
 out=Image.new('RGB',(cols*cw+2*pad,top+rows*ch+pad),(247,246,241));dr=ImageDraw.Draw(out)
 dr.text((pad,28),title,font=font(34,True),fill='#293c38');dr.text((pad,83),sub,font=font(19),fill='#66746c')
 for i,(file,label,cap) in enumerate(items):
  x=pad+(i%cols)*cw;y=top+(i//cols)*ch;im=Image.open(OUT/file).convert('RGB');im=im.resize((cw-18,526),Image.Resampling.LANCZOS);out.paste(im,(x,y));dr.text((x+8,y+538),label,font=font(23,True),fill='#293c38');dr.text((x+8,y+574),cap,font=font(17),fill='#66746c')
 out.save(ROOT/name)
board('component_validation_board.png','STILLWOOD / BUILT COMPONENT STUDIES','Actual cuboid geometry / offline renders / proposed world units: 1 unit = 1 metre',[
 ('doric_eye.png','01 / Doric-inspired column','3,142 sticks | 28.44 m | low-eye view'),
 ('ionic_eye.png','02 / Ionic-inspired column','3,306 sticks | 29.94 m | low-eye view'),
 ('corinthian_eye.png','03 / Corinthian-inspired column','4,600 sticks | 30.44 m | low-eye view'),
 ('broad_shallow_stairs_orbit.png','04 / Broad shallow steps','1,956 sticks | rise 0.25 m / tread 2 m | orbit'),
 ('spillway_fins_eye.png','05 / Four-bay spillway','15,010 sticks | 61.75 m | low-eye view'),
 ('entrance_composition_eye.png','06 / Steps + columned gateway','9,272 sticks | 38.25 m | low-eye view')],3)
board('camera_comparison.png','SAME GEOMETRY / TWO CAMERA MODES','Left: current camera logic reproduced offline. Right: proposed exploration camera.',[
 ('entrance_composition_orbit.png','Current orbit / 35-degree FOV','Fit-all distance / phi 0.95 / theta pi/4'),
 ('entrance_composition_eye.png','Proposed eye / 55-degree FOV','Eye height 1.65 m / no automatic fit-all')],2)
# Lightweight local gallery deliberately needs no WebGL or JavaScript.
names=[e['name'] for e in json.loads((OUT/'manifest.json').read_text())]
html='''<!doctype html><meta charset="utf-8"><title>Stillwood component lab</title><style>body{max-width:1300px;margin:40px auto;font:17px system-ui;background:#f5f3ed;color:#253b34}section{padding:24px 0;border-bottom:1px solid #ccc}.views{display:flex;flex-wrap:wrap}figure{width:46%;margin:1%}img{width:100%}a{color:#246259}</style><h1>Stillwood 构件验证</h1><p>离线样件；非线上截图。只有 132 根原规格台阶运行了项目物理代码。其余为静态展览预设。</p><p><a href="VALIDATION.md">验证说明与实施边界</a> · <a href="output/manifest.json">实际根数与包围盒</a></p>'''
for n in names:
 html+=f'<section><h2>{n}</h2><a href="output/{n}.glb">GLB</a> · <a href="output/{n}.json">逐根木条 JSON</a><div class="views">'
 for mode,cap in [('orbit','当前相机逻辑：35°，自动容纳整个模型'),('eye','拟议低机位：眼高 1.65，55°（单独台阶为65°）')]:html+=f'<figure><img src="output/{n}_{mode}.png"><figcaption>{cap}</figcaption></figure>'
 html+='</div></section>'
html+='<section><h2>132 根台阶：物理静止后的真实姿态</h2><img width="900" src="output/stairs_132_settled_orbit.png"></section>'
(ROOT/'review.html').write_text(html)
