from pathlib import Path
import json, math, numpy as np, trimesh
ROOT=Path(__file__).parent
OUT=ROOT/'output';OUT.mkdir(exist_ok=True)
class Scene:
 def __init__(self,name):self.name=name;self.parts=[]
 def box(self,p,size,R=None,tag='wood',group='body'):
  self.parts.append(dict(p=list(map(float,p)),size=list(map(float,size)),R=np.asarray(np.eye(3) if R is None else R).tolist(),tag=tag,group=group))
 def beam(self,a,b,u=4,group='body'):
  a,b=np.array(a,float),np.array(b,float);v=b-a;l=np.linalg.norm(v)
  if l<1e-8:return
  x=v/l;ref=np.array([0,1,0]) if abs(x[1])<.95 else np.array([0,0,1]);z=np.cross(x,ref);z/=np.linalg.norm(z);y=np.cross(z,x);R=np.stack([x,y,z],axis=1)
  n=max(1,math.ceil(l/u));centers=[(a+b)/2] if n==1 else [a+x*(u/2+i*(l-u)/(n-1)) for i in range(n)]
  for c in centers:self.box(c,[u,u/8,u/8],R,group=group)
 def ring(self,r,y,n=32,u=1,center=(0,0),group='ring'):
  for i in range(n):
   a=2*math.pi*i/n;b=2*math.pi*(i+1)/n
   self.beam([center[0]+r*math.cos(a),y,center[1]+r*math.sin(a)],[center[0]+r*math.cos(b),y,center[1]+r*math.sin(b)],u,group)
 def deck(self,w,d,y,u=4,center=(0,0),group='plinth'):
  for z in np.arange(-d/2+u/16,d/2,u/8):self.beam([center[0]-w/2,y,center[1]+z],[center[0]+w/2,y,center[1]+z],u,group)
 def moved(self,other,offset):
  for p in other.parts:self.parts.append({**p,'p':(np.array(p['p'])+offset).tolist()})
 def bounds(self):
  lo=np.full(3,np.inf);hi=-lo
  for p in self.parts:
   e=np.abs(p['R'])@(np.array(p['size'])/2);lo=np.minimum(lo,np.array(p['p'])-e);hi=np.maximum(hi,np.array(p['p'])+e)
  return lo,hi
 def save(self):
  lo,hi=self.bounds();groups={}
  for p in self.parts:groups[p['group']]=groups.get(p['group'],0)+1
  data={'name':self.name,'parts':self.parts,'part_count':len(self.parts),'bounds':[lo.tolist(),hi.tolist()],'groups':groups,'physical_status':'NOT_PHYSICS_TESTED'}
  (OUT/(self.name+'.json')).write_text(json.dumps(data,separators=(',',':')))
  meshes=[]
  for i,p in enumerate(self.parts):
   m=trimesh.creation.box(p['size']);T=np.eye(4);T[:3,:3]=p['R'];T[:3,3]=p['p'];m.apply_transform(T);v=.94+.1*((i*137%1000)/1000);m.visual.face_colors=np.array([188*v,145*v,103*v,255],dtype=np.uint8);meshes.append(m)
  trimesh.util.concatenate(meshes).export(OUT/(self.name+'.glb'))
  return {'name':self.name,'count':len(self.parts),'bounds':[lo.tolist(),hi.tolist()],'groups':groups}

def column(kind):
 s=Scene(kind);base=0 if kind=='doric' else 2
 for j in range(4):s.deck(7-j*.35,7-j*.35,j*.5+.25,group='base')
 shaft0=2;shaft1=26;N=20 if kind=='doric' else 24
 # Flutes are actual recessed channels between narrower exterior strips.
 for k in range(8):
  y0=shaft0+3*k;y1=y0+3
  r0=2.4-.5*k/8+.14*math.sin(math.pi*k/8);r1=2.4-.5*(k+1)/8+.14*math.sin(math.pi*(k+1)/8)
  for i in range(N):
   a=2*math.pi*i/N
   s.beam([r0*math.cos(a),y0,r0*math.sin(a)],[r1*math.cos(a),y1,r1*math.sin(a)],4,'shaft_ribs')
   a+=math.pi/N
   s.beam([(r0-.27)*math.cos(a),y0,(r0-.27)*math.sin(a)],[(r1-.27)*math.cos(a),y1,(r1-.27)*math.sin(a)],1,'recessed_flute_backs')
  s.ring((r0+r1)/2-.2,(y0+y1)/2,24,1,group='shaft_ties')
 for j in range(3):s.ring(1.98+j*.08,26+j*.125,32,1,group='neck')
 if kind=='doric':
  for j in range(12):s.ring(2+j*.07,26.4+j*.125,40,1,group='echinus')
  for j in range(4):s.deck(6.4+j*.12,6.4+j*.12,28+j*.125,1,group='abacus')
 elif kind=='ionic':
  for j in range(8):s.ring(2.05+j*.1,26.4+j*.125,40,1,group='echinus')
  for z in [-2.05,2.05]:
   for sign in [-1,1]:
    cx=sign*2.15
    pts=[]
    for t in np.linspace(0,2.5*math.pi,41):
     r=1.25*(1-t/(3.2*math.pi));pts.append([cx+sign*r*math.cos(t),28.1+r*math.sin(t),z])
    for a,b in zip(pts,pts[1:]):s.beam(a,b,1,'volute')
   s.beam([-2,28.65,z],[2,28.65,z],4,'capital_crossbar')
  for j in range(4):s.deck(7.8,5.8,29.5+j*.125,1,group='abacus')
 else:
  for j in range(24):s.ring(2.0+j*.035,26.4+j*.125,40,1,group='capital_basket')
  for row in range(2):
   for i in range(8):
    a=2*math.pi*(i+row*.5)/8
    for lane in [-2,-1,0,1,2]:
     pts=[]
     for t in np.linspace(0,1,10):
      r=2.05+1.4*t*t;y=26.2+row*1.15+2.5*t-.5*t*t
      da=lane*.07*math.sin(math.pi*t)
      pts.append([r*math.cos(a+da),y,r*math.sin(a+da)])
     for p,q in zip(pts,pts[1:]):s.beam(p,q,1,'acanthus_leaf_lamellae')
  for j in range(4):s.deck(7.0,7.0,30+j*.125,1,group='abacus')
 return s

def live_stairs():
 s=Scene('stairs_132_current_sticks')
 for j,(nx,nz) in enumerate([(4,16),(3,12),(3,8),(2,4)]):
  for ix in range(nx):
   for iz in range(nz):s.box([(ix-(nx-1)/2)*8.02,j+.505,(iz-(nz-1)/2)*1.02], [8,1,1],group=f'course_{j+1}')
 return s

def grand_stairs():
 s=Scene('broad_shallow_stairs')
 # Thin visible shell: four rows per tread, closed side risers, stable static exhibit.
 for j in range(16):
  w=64-2*j;d=72-4*j;y=.25+.25*j
  zfront=d/2
  for row in range(4):s.beam([-w/2,y,zfront-.25-row*.5],[w/2,y,zfront-.25-row*.5],4,f'tread_{j+1:02d}')
  for sign in [-1,1]:
   for row in range(2):s.beam([sign*(w/2-.25-row*.5),y,-d/2],[sign*(w/2-.25-row*.5),y,d/2],4,'side_steps')
  s.beam([-w/2,y,-d/2+.25],[w/2,y,-d/2+.25],4,'back_steps')
 s.deck(34,8,4.0,4,group='upper_landing')
 # Low side plinths establish width; no unrelated tower to fake magnitude.
 for x in [-34,34]:
  for j in range(6):s.deck(4.5-j*.25,5-j*.25,.25+j*.5,4,center=(x,28),group='side_pedestal')
 return s

def dam():
 s=Scene('spillway_fins')
 for j in range(112):
  y=j*.5+.25;t=y/56;back=-6;front=4+30*(1-t)**1.7
  # The dam back shell is real laid timber, deliberately not a single cuboid.
  for row in range(2):s.beam([-36,y,back+row*.5],[36,y,back+row*.5],4,'upstream_face')
  for x in [-32,-16,0,16,32]:
   hw=1.1+2.1*(1-t)
   for sign in [-1,1]:
    s.beam([x+sign*hw,y,back],[x+sign*hw,y,front],4,'fin_side_courses')
   s.beam([x-hw,y,front],[x+hw,y,front],4,'fin_nose')
  # At head of the four bays: recessed gate frame, kept open below.
 for x in [-24,-8,8,24]:
  for y in np.arange(40.5,52,.5):s.beam([x-5,y,-2.5],[x+5,y,-2.5],4,'gate_slats')
  for xx in [x-5.8,x+5.8]:s.beam([xx,39,-1],[xx,54,-1],4,'gate_rails')
  s.beam([x-6,53,-1],[x+6,53,-1],4,'gate_lintel')
  for yy in np.arange(.25,40,.5):
   zz=5+20*(1-yy/56)**2
   s.beam([x-5,yy,zz],[x+5,yy,zz],4,'continuous_chute_face')
  # Downstream channel side ledges make the fall legible without simulated water.
  for sign in [-1,1]:
   pts=[]
   for yy in np.linspace(2,39,20):pts.append([x+sign*5,yy,5+20*(1-yy/56)**2])
   for a,b in zip(pts,pts[1:]):s.beam(a,b,4,'chute_edge')
 for j in range(4):s.deck(76,10,56.25+j*.5,4,center=(0,-1),group='crest_bridge')
 for x in [-32,-16,0,16,32]:
  for j in range(4):s.deck(6-j*.6,6-j*.6,58.5+j,4,center=(x,-1),group='crest_pier_cap')
 for x in np.arange(-36,37,2):
  for z in [-5.5,3.5]:s.beam([x,58,z],[x,60,z],1,'rail_post')
 for z in [-5.5,3.5]:s.beam([-37,60,z],[37,60,z],1,'rail_top')
 return s

def entrance():
 s=Scene('entrance_composition');s.moved(grand_stairs(),[0,0,0])
 col=column('ionic')
 for x in [-12,12]:s.moved(col,[x,4.25,0])
 for j in range(8):
  for z in [-2.5,-2,-1.5,-1,-.5,0,.5,1,1.5,2,2.5]:s.beam([-16,34.5+j*.5,z],[16,34.5+j*.5,z],4,'entablature')
 return s

scenes=[entrance(),column('doric'),column('ionic'),column('corinthian'),live_stairs(),grand_stairs(),dam()]
manifest=[]
for s in scenes:
 r=s.save();manifest.append(r);print(s.name,r['count'],np.round(np.subtract(*reversed(r['bounds'])),2))
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2))
