import {readFileSync,writeFileSync} from 'node:fs';
import {PhysicsWorld,initPhysics} from './src/server/core/physics.ts';
import {currentPhysicsConfig} from './src/shared/config.ts';
await initPhysics();const cfg=currentPhysicsConfig();const w=PhysicsWorld.create(cfg);
const data=JSON.parse(readFileSync(new URL('./output/stairs_132_current_sticks.json',import.meta.url)));
const accepted=[],rejected=[],adjustments=[];let index=0;
for(const p of data.parts){const pose={p:p.p,q:[0,0,0,1]};let result=w.checkPlacement(pose);
 if(result.problem){rejected.push({index,pose,...result});}
 else{const id='sample-'+index;w.addStick({id,authorId:'offline-test',createdBy:id,seed:index,placedAt:0},pose);accepted.push({id,initial:pose.p});}
 for(let j=0;j<30;j++)w.step();index++;
}
for(let j=0;j<1200;j++)w.step();
const supported=w.supportedFromTable();const final=w.bodies();let maxMove=0;
for(const a of accepted){const p=w.pose(a.id)?.p;if(p)maxMove=Math.max(maxMove,Math.hypot(...p.map((v,i)=>v-a.initial[i])));}
const result={scope:'Offline execution of fetched repository PhysicsWorld; no live HTTP/WebSocket commands or persistence tested',engine:'@dimforge/rapier3d-compat@0.19.3',physicsConfigVersion:cfg.physicsConfigVersion,inputPieces:data.parts.length,adjustments,accepted:accepted.length,rejected,supported:supported.size,quiet:w.isQuiet(),allSleeping:w.allSleeping(),healthy:w.healthy(),supportedHeight:w.supportedHeight(),maxCenterDisplacement:maxMove,simulationSeconds:w.tick*cfg.fixedStep,finalBodies:final};
writeFileSync(new URL('./output/stairs_physics_result.json',import.meta.url),JSON.stringify(result,null,2));
console.log(JSON.stringify({...result,finalBodies:undefined,rejected:rejected.slice(0,8)},null,2));w.free();
